CREATE DATABASE sales;
-- Import sales_data.csv file into sales database

USE sales;

SELECT * from sales_data;



-- SELECT
-- Fetch all the records from sales_data table
SELECT * FROM sales_data;



-- SELECT DISTINCT
-- Find the distinct categories in this data
SELECT distinct(PRODUCTLINE) FROM sales_data;




-- count of distinct categories
SELECT count(distinct(PRODUCTLINE)) 
FROM sales_data;

SELECT sum(sales) from sales_data;
-- ALIAS
SELECT ORDERNUMBER AS order_num FROM sales_data;


-- GroupBy
-- to find total sales over different Products
SELECT SUM(sales) , productline FROM sales_data 
GROUP BY productline;


SELECT sum(sales),city from sales_data group by city;

-- HAVING cluse

-- Find Productline which has orders Greater 500

SELECT COUNT(ORDERNUMBER), Productline FROM sales_data GROUP BY PRODUCTLINE 
HAVING COUNT(ORDERNUMBER)>500;
