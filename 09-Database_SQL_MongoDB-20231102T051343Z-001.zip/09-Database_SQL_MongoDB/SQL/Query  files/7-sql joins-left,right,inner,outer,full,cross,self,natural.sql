CREATE DATABASE joins;
USE joins;

-- create employee table and department table
CREATE TABLE employee
(empid VARCHAR(10) UNIQUE, 
empname VARCHAR(20), salary int,deptid VARCHAR(10) PRIMARY KEY);

INSERT INTO employee VALUES
('E1',"john",45000,'D1'),
('E2',"mary",72000,'D2'),
('E3',"steve",85000,'D3'),
('E4',"helen",60000,'D4'),
('E5',"joe",35000,'D7');
SELECT * FROM employee;


-- Department Table
CREATE TABLE department
(deptid VARCHAR(10) PRIMARY KEY, deptname VARCHAR(10));
INSERT INTO department VALUES
('D1','HR'),
('D2','Admin'),
('D3','Sales'),
('D4','IT'),
('D5','HR');

SELECT * FROM department;
SELECT * FROM employee;

-- Inner join 
SELECT e.empid,e.empname,e.salary,e.deptid,d.deptname 
FROM employee e INNER JOIN department d on e.deptid=d.deptid;

-- Left Join 
SELECT e.empid,e.empname,e.salary,e.deptid,d.deptname 
FROM employee e LEFT JOIN department d on e.deptid=d.deptid;

-- Right Join 
SELECT e.empid,e.empname,e.salary,e.deptid,d.deptname 
FROM employee e RIGHT JOIN department d on e.deptid=d.deptid;

-- Outer Join
SELECT e.empid,e.empname,e.salary,e.deptid,d.deptname 
FROM employee e LEFT JOIN department d on e.deptid=d.deptid


UNION
SELECT e.empid,e.empname,e.salary,e.deptid,d.deptname 
FROM employee e RIGHT JOIN department d on e.deptid=d.deptid;


-- Cross Join
 SELECT e.empid,d.deptname FROM employee e CROSS JOIN department d;
 

