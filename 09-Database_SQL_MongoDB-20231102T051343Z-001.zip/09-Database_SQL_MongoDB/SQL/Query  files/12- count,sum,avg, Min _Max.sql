/* TASK: 
1)Find the least sales in Motorcycles.
2)Find the highest sale in paris city.
3) Find the average sale in  Classic Cars.
*/




SELECT * FROM sales_data;
-- COUNT
SELECT COUNT(*) FROM sales_data;

-- SUM
SELECT SUM(SALES) FROM sales_data; 

-- AVG
SELECT AVG(SALES) FROM sales_data;

-- MIN & MAX
SELECT MIN(SALES) FROM sales_data;
SELECT MAX(SALES) FROM sales_data;
select avg(sales) from sales_data;

select quantityordered,customername 
from sales_data order by quantityordered limit 1;

select quantityordered,state,customername from sales_data
order by quantityordered desc limit 1;


select quantityordered,state from sales_data;

select * from sales_data;









