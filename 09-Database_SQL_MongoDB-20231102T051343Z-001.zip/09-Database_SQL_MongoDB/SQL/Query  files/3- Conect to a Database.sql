-- NOTE: When connecting to Database don't do copy paste, manually type
-- Connect to DATABSE
-- 1)click on Database
-- 2)connect to databse
-- 3)give username, password-store it in vault
-- 4)Right cick on datamites_sql
-- 5)Set as default schema

  