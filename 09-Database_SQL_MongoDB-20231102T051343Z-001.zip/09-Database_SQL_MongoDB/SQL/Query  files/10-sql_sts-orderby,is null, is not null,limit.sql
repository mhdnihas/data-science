USE sales;

SELECT * FROM sales_data;

-- ORDER BY
SELECT sales,city,productline from sales_data ORDER BY sales;


-- get all the records related to Motorcycles and order by Quantity ordered 
SELECT * FROM sales_data WHERE PRODUCTLINE ='Motorcycles' ORDER BY
 QUANTITYORDERED desc;
 
 -- Lexicographic ordering
SELECT productline FROM sales_data ORDER BY productline;

-- get the highest quantity ordered.
SELECT * FROM sales_data ORDER BY QUANTITYORDERED DESC; 

-- TASK:
-- get the highest Motorcycles quantity ordered. 
-- ( get only QUANTITYORDERED,PRODUCTLINE column)

-- IS NULL
SELECT count(*) FROM sales_data WHERE SALES IS NULL;

SELECT count(*) FROM sales_data WHERE ORDERNUMBER IS NOT NULL;

SELECT count(*)
FROM sales_data
WHERE STATE IS NULL OR STATE = '';

-- LIMIT
-- lets get the top five highest sales
SELECT sales,state from sales_data ORDER BY Sales DESC LIMIT 5;



SELECT sales,state FROM sales_data  ORDER BY Sales DESC LIMIT 5,3; 
-- Limit start_row, count;

-- To get a range of records LIMIT 5,10 (start_index,count)

-- TASK: Get the highest sale that happend in CA.


select sales,city,state,productline from sales_data 
order by sales desc limit 1;

