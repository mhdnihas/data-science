USE sales;
SELECT * FROM sales_data;

-- Find all orders from NewYork state 
SELECT * FROM sales_data WHERE STATE='NY';




-- Find all details where QUANTITYORDERED is greater than 30
SELECT * FROM sales_data WHERE QUANTITYORDERED>50;

-- Find all detilas where sales greater than 10,000
SELECT * FROM sales_data WHERE SALES>10000;

-- Count the number of sales between 2000 and 3000 ??
select count(*) from sales_data WHERE SALES BETWEEN 2000 AND 3000;


-- AND 
-- Find all detilas where sales greater than 10,000 and in the state of california(CA)
SELECT * FROM sales_data WHERE SALES>10000 AND STATE="CA" ;

-- OR
-- Find all detilas  in california where QUANTITYORDERED is greater than 70;
SELECT * FROM sales_data WHERE QUANTITYORDERED>70  OR STATE="CA" ;


-- NOT
-- Find all records except records related to CA
SELECT * FROM sales_data WHERE NOT STATE="CA" ;


-- TASK:Calc the sum of sales in NYC city where quantityordered > 25



SELECT sum(sales),city,quantityordered from sales_data WHERE 
city='NYC' and quantityordered>25;