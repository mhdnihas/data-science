
CREATE DATABASE superstore;

USE superstore;

CREATE TABLE product(
product1 varchar(15) NOT NULL,
price varchar(5),
exp_date DATE);

INSERT INTO product VALUES(
"chips", "20" ,"2025-02-05");

SELECT * FROM product;

-- Drop Table
DROP TABLE product;

-- UPDATE 
USE employee;
SELECT * FROM employee_details;

UPDATE employee_details
SET emp_name="JOHN",emp_age=40 WHERE emp_id="E4001";

-- DELETE
DELETE FROM employee_details WHERE emp_id="E4006";

DELETE FROM employee_details WHERE emp_name="Thaman";


-- describe= Structure, dtype,constrains you have used.
desc employee_details;



