-- ALTER 
-- ADD function
ALTER TABLE employee_details  ADD emp_experience int ;

SELECT * FROM employee_details;

 

-- DROP
ALTER TABLE employee_details DROP COLUMN emp_experience;

-- MODIFY
desc employee_details;
ALTER TABLE employee_details MODIFY emp_name VARCHAR(50);

-- RENAME
ALTER TABLE employee_details RENAME COLUMN emp_age to age_of_employee;

-- RENAME TABLE

ALTER TABLE employee_details RENAME TO employee_data ;

-- TRUNCATE
TRUNCATE TABLE employee_details;  


