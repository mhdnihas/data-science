use sales;
-- IN Operator
 SELECT * FROM sales_data;
 
 -- Find all records in the month 2,7,8 from MONTH_ID column
 -- Using IN 
 SELECT * FROM sales_data WHERE MONTH_ID IN (2,7,8);
 
 -- Using OR we had to 
select * from sales_data where MONTH_ID=2  ; 

-- BETWEEN operator 
-- Find all the records of customers whose order quantity is between 39 to 42
SELECT * FROM sales_data WHERE QUANTITYORDERED 
BETWEEN 39 and 42;

 
 -- Find the total orders betwwen 2003 and 2004
 SELECT count(*) FROM sales_data WHERE YEAR_ID BETWEEN 2003 and 2004;
 
 -- LIKE operator
 -- Find all records where customername is starting with r
 
  SELECT * FROM sales_data WHERE CUSTOMERNAME LIKE 'r%';
 
 
 -- Find all records where Address is Moro
  SELECT * FROM sales_data WHERE ADDRESSLINE1 LIKE '%moro%';
