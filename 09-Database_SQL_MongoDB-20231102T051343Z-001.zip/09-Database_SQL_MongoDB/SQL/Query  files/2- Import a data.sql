-- IMPORT a data(from csv file)
CREATE DATABASE sales;














-- To import data, Select a database
-- 1)Right Click on: Tabels
-- 2)Select: Table Data Import Wizard
-- 3)Browse and select a csv file.alter

-- lets view the data in sales_data_sample

-- Make sales as "default Database"
USE sales;



SELECT * FROM sales_data;
SELECT ORDERNUMBER FROM sales_data;



-- To see the count of rows
SELECT COUNT(*) FROM sales_data;


DROP DATABASE sales;
