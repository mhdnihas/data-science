-- Comment by using two hyphen
/*  */

-- create a employee database
CREATE DATABASE employee;


-- see all available databases
SHOW DATABASES;

-- delete employee databse
DROP DATABASE employee; 

