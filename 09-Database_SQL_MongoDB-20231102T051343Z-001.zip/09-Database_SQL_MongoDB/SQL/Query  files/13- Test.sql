create Table test (c1 varchar(20),c2 varchar(30),c3 varchar(30),c4 varchar(30), c5 varchar(30));


INSERT INTO test (c1,c2,c3,c4,c5)
SELECT e.empid,e.empname,e.deptid,d.deptname 
FROM employee e INNER JOIN department d on e.deptid=d.deptid;


select * from test;


use sales;
SELECT
    COUNT(*) AS sales_data,
    COUNT(state) AS non_null_rows,
    COUNT(*) - COUNT(column_name) AS null_rows
FROM
    sales_table;
    
SELECT count(*) from sales_data where state is null;
-- NULL,''

select * from sales_data;


SELECT count(*)
FROM sales_data
WHERE STATE IS NULL OR STATE = '' ;




