CREATE DATABASE employee;
-- create a table of employee_details



USE employee;




CREATE TABLE employee_details (
emp_id VARCHAR(10) PRIMARY KEY,
emp_name VARCHAR(20) NOT NULL,
emp_designation VARCHAR(20),
emp_age int 
);

-- Insert into
INSERT INTO employee_details VALUES
("E4001","Pradeep","HR",36),
("E4002","Ashok","Manager",28),
("E4003","Pavan","Asst.Manager",28),
("E4004","Santosh","Store Manager",25),
("E4005","Thaman","General Manager",26);



-- To see what is there is Table
SELECT * FROM employee_details;





-- add one more entry
INSERT INTO employee_details VALUES
("E4006","Raj","Sales Head",24);

