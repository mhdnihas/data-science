
-- Get the customer table 
SELECT * FROM customers;

-- This is how you fetch your data
-- Lets see how to Export/Import in Output table.

