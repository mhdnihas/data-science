-- SubQuery

CREATE database subquery;
USE subquery;



-- Find the details of customers, whose payment amount is more than the average of total amount paid by all customers.

SELECT * FROM payment;
-- subquery using  Comparison Operator(Single output)
SELECT avg(amount) FROM payment;

SELECT * FROM payment WHERE amount> (SELECT avg(amount) FROM payment);

-- Subquery using IN (Multiple output)
SELECT customer_id FROM customer ;

-- get the details of these customers

SELECT customer_id, amount, mode FROM payment WHERE customer_id 
IN (SELECT customer_id FROM customer);

-- Subquery using EXISTS
SELECT customer_id, amount 	FROM payment WHERE  amount >70;

SELECT first_name, last_name FROM customer c WHERE EXISTS 
                    (SELECT customer_id, amount 	
                    FROM payment p  WHERE p.customer_id = c.customer_id AND  amount >70)
